<h2>Log In</h2>

<div class="info">Selamat datang di halaman login <strong>  PT.PLN ULP LABUHANBATU</strong></div>

<form action="<?php echo URL; ?>/Dashboard/index" method="post">
    <p>username</p>
    <input type="text">
    <p>password</p>
    <input type="password">
    <input type="submit" value="Login">
</form>
